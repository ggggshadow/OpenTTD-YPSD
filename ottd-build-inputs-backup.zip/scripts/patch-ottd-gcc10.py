#!/usr/bin/env python3
"""
Apply all GCC 10 MinGW compat patches to OpenTTD 15.3 source tree.
Usage: python3 patch-ottd-gcc10.py <path-to-ottd-source>
Idempotent: checks before patching.
Session notes: all patches confirmed working with PCH disabled + pragma O1.
"""
import sys, os, re, glob

SRC = sys.argv[1] if len(sys.argv) > 1 else "/tmp/ottd15/openttd-15.3"

def read(path):
    with open(path) as f: return f.read()

def write(path, content):
    with open(path, 'w') as f: f.write(content)

def patch(path, old, new, name=""):
    full = os.path.join(SRC, path)
    c = read(full)
    if old in c:
        write(full, c.replace(old, new))
        print(f"  PATCHED: {path} ({name})")
    elif new in c:
        print(f"  OK (already): {path} ({name})")
    else:
        print(f"  WARNING NOT FOUND: {path} ({name})")
        key = old.split('\n')[0][:60]
        idx = c.find(key[:20])
        if idx >= 0:
            print(f"    Context: {repr(c[max(0,idx-20):idx+100])}")

print("=== Applying GCC 10 MinGW compat patches ===")

# ─── 1. tilearea_type.h — SpiralTileIterator ──────────────────────────────
patch("src/tilearea_type.h",
    'SpiralTileIterator(TileIndex start_north, uint radius, uint w, uint h);\n\n\tbool operator==(const SpiralTileIterator &rhs) const { return this->x == rhs.x && this->y == rhs.y; }\n\tbool operator==(const std::default_sentinel_t &) const { return this->IsEnd(); }',
    '''SpiralTileIterator(TileIndex start_north, uint radius, uint w, uint h);
#if defined(__GNUC__) && __GNUC__ < 11 && !defined(__clang__)
\tSpiralTileIterator() = default;
#endif

#if defined(__GNUC__) && __GNUC__ < 11 && !defined(__clang__)
\t/* GCC 10: end() returns SpiralTileIterator{}; detect sentinel via IsEnd(). */
\tbool operator==(const SpiralTileIterator &rhs) const {
\t\tif (rhs.IsEnd()) return this->IsEnd();
\t\tif (this->IsEnd()) return false;
\t\treturn this->x == rhs.x && this->y == rhs.y;
\t}
#else
\tbool operator==(const SpiralTileIterator &rhs) const { return this->x == rhs.x && this->y == rhs.y; }
\tbool operator==(const std::default_sentinel_t &) const { return this->IsEnd(); }
#endif''',
    "SpiralTileIterator operators")

patch("src/tilearea_type.h",
    '\tvoid SkipOutsideMap();\n\tvoid InitPosition();\n\tvoid Increment();\n\n\t/**\n\t * Test whether the iterator reached the end.\n\t */\n\tbool IsEnd() const\n\t{\n\t\treturn this->cur_radius == this->max_radius && this->dir != INVALID_DIAGDIR;\n\t}\n};',
    '''\tvoid SkipOutsideMap();
\tvoid InitPosition();
\tvoid Increment();

\t/**
\t * Test whether the iterator reached the end.
\t */
\tbool IsEnd() const
\t{
\t\treturn this->cur_radius == this->max_radius && this->dir != INVALID_DIAGDIR;
\t}

\tfriend class SpiralTileSequence;
};''',
    "SpiralTileIterator friend")

patch("src/tilearea_type.h",
    '\tSpiralTileIterator begin() const { return start; }\n\tstd::default_sentinel_t end() const { return std::default_sentinel_t(); }',
    '''\tSpiralTileIterator begin() const { return start; }
#if defined(__GNUC__) && __GNUC__ < 11 && !defined(__clang__)
\tSpiralTileIterator end() const { return SpiralTileIterator{}; }
#else
\tstd::default_sentinel_t end() const { return std::default_sentinel_t(); }
#endif''',
    "SpiralTileSequence::end()")

patch("src/tilearea_type.h",
    '\n};\n\n#endif /* TILEAREA_TYPE_H */',
    '''\n};

#if defined(__GNUC__) && __GNUC__ < 11 && !defined(__clang__)
template<> inline constexpr bool std::ranges::enable_borrowed_range<SpiralTileSequence> = true;
#endif

#endif /* TILEAREA_TYPE_H */''',
    "SpiralTileSequence enable_borrowed_range")

# ─── 2. vehicle_func.h — VehiclesOnTile + VehiclesNearTileXY ──────────────
c = read(os.path.join(SRC, "src/vehicle_func.h"))
already = 'Iterator() = default;' in c
if not already:
    c = c.replace(
        '\t\texplicit Iterator(TileIndex tile);\n\n\t\tbool operator==(const Iterator &rhs) const { return this->current == rhs.current; }\n\t\tbool operator==(const std::default_sentinel_t &) const { return this->current == nullptr; }',
        '\t\texplicit Iterator(TileIndex tile);\n#if defined(__GNUC__) && __GNUC__ < 11 && !defined(__clang__)\n\t\tIterator() = default;\n#endif\n\n\t\tbool operator==(const Iterator &rhs) const { return this->current == rhs.current; }\n#if !(defined(__GNUC__) && __GNUC__ < 11 && !defined(__clang__))\n\t\tbool operator==(const std::default_sentinel_t &) const { return this->current == nullptr; }\n#endif'
    )
    c = c.replace(
        '\t\texplicit Iterator(int32_t x, int32_t y, uint max_dist);\n\n\t\tbool operator==(const Iterator &rhs) const { return this->current_veh == rhs.current_veh; }\n\t\tbool operator==(const std::default_sentinel_t &) const { return this->current_veh == nullptr; }',
        '\t\texplicit Iterator(int32_t x, int32_t y, uint max_dist);\n#if defined(__GNUC__) && __GNUC__ < 11 && !defined(__clang__)\n\t\tIterator() = default;\n#endif\n\n\t\tbool operator==(const Iterator &rhs) const { return this->current_veh == rhs.current_veh; }\n#if !(defined(__GNUC__) && __GNUC__ < 11 && !defined(__clang__))\n\t\tbool operator==(const std::default_sentinel_t &) const { return this->current_veh == nullptr; }\n#endif'
    )
    c = c.replace(
        '\texplicit VehiclesOnTile(TileIndex tile) : start(tile) {}\n\tIterator begin() const { return this->start; }\n\tstd::default_sentinel_t end() const { return std::default_sentinel_t(); }\nprivate:\n\tIterator start;\n};',
        '\texplicit VehiclesOnTile(TileIndex tile) : start(tile) {}\n\tIterator begin() const { return this->start; }\n#if defined(__GNUC__) && __GNUC__ < 11 && !defined(__clang__)\n\tIterator end() const { return Iterator{}; }\n#else\n\tstd::default_sentinel_t end() const { return std::default_sentinel_t(); }\n#endif\nprivate:\n\tIterator start;\n};'
    )
    c = c.replace(
        '\texplicit VehiclesNearTileXY(int32_t x, int32_t y, uint max_dist) : start(x, y, max_dist) {}\n\tIterator begin() const { return this->start; }\n\tstd::default_sentinel_t end() const { return std::default_sentinel_t(); }\nprivate:\n\tIterator start;\n};',
        '\texplicit VehiclesNearTileXY(int32_t x, int32_t y, uint max_dist) : start(x, y, max_dist) {}\n\tIterator begin() const { return this->start; }\n#if defined(__GNUC__) && __GNUC__ < 11 && !defined(__clang__)\n\tIterator end() const { return Iterator{}; }\n#else\n\tstd::default_sentinel_t end() const { return std::default_sentinel_t(); }\n#endif\nprivate:\n\tIterator start;\n};'
    )
    if 'enable_borrowed_range<VehiclesOnTile>' not in c:
        c = c.replace('#endif /* VEHICLE_FUNC_H */',
            '#if defined(__GNUC__) && __GNUC__ < 11 && !defined(__clang__)\ntemplate<> inline constexpr bool std::ranges::enable_borrowed_range<VehiclesOnTile> = true;\ntemplate<> inline constexpr bool std::ranges::enable_borrowed_range<VehiclesNearTileXY> = true;\n#endif\n\n#endif /* VEHICLE_FUNC_H */')
    write(os.path.join(SRC, "src/vehicle_func.h"), c)
    print("  PATCHED: src/vehicle_func.h (VehiclesOnTile + VehiclesNearTileXY)")
else:
    print("  OK (already): src/vehicle_func.h")

# ─── 3. station_layout_type.h ──────────────────────────────────────────────
patch("src/station_layout_type.h",
    '\tbool operator==(const std::default_sentinel_t &) const { return this->position == this->stl.platforms * this->stl.length; }',
    '''#if !(defined(__GNUC__) && __GNUC__ < 11 && !defined(__clang__))
\tbool operator==(const std::default_sentinel_t &) const { return this->position == this->stl.platforms * this->stl.length; }
#endif''',
    "sentinel op==")

patch("src/station_layout_type.h",
    '\tIterator begin() const { return Iterator(*this); }\n\tstd::default_sentinel_t end() const { return std::default_sentinel_t(); }',
    '''\tIterator begin() const { return Iterator(*this); }
#if defined(__GNUC__) && __GNUC__ < 11 && !defined(__clang__)
\tIterator end() const {
\t\tIterator it(*this);
\t\tit.position = this->platforms * this->length;
\t\treturn it;
\t}
#else
\tstd::default_sentinel_t end() const { return std::default_sentinel_t(); }
#endif''',
    "end()")

patch("src/station_layout_type.h",
    '\t\tIterator(const RailStationTileLayout &stl) : stl(stl) {}',
    '''\t\tIterator(const RailStationTileLayout &stl) : stl(stl) {}
\t\tfriend class RailStationTileLayout;''',
    "Iterator friend class")

# ─── 4. stdafx.h — add <sstream> and <bit> ────────────────────────────────
patch("src/stdafx.h",
    '#include <string>',
    '#include <bit>\n#include <sstream>\n#include <string>',
    "sstream+bit")

# ─── 5. lrucache.hpp — GetIfValid heterogeneous find ──────────────────────
patch("src/misc/lrucache.hpp",
    '''\tinline Tdata *GetIfValid(const auto &key)
\t{
\t\tauto it = this->lookup.find(key);
\t\tif (it == this->lookup.end()) return nullptr;

\t\t/* Move to front if needed. */
\t\tthis->data.splice(this->data.begin(), this->data, it->second);

\t\treturn &this->data.front().second;
\t}''',
    '''\tinline Tdata *GetIfValid(const auto &key)
\t{
#if defined(__GNUC__) && __GNUC__ < 11 && !defined(__clang__)
\t\t/* GCC 10 lacks P0919R3 heterogeneous unordered_map::find; linear scan. */
\t\tfor (auto lit = this->data.begin(); lit != this->data.end(); ++lit) {
\t\t\tif (Tequality{}(lit->first, key)) {
\t\t\t\tthis->data.splice(this->data.begin(), this->data, lit);
\t\t\t\treturn &this->data.front().second;
\t\t\t}
\t\t}
\t\treturn nullptr;
#else
\t\tauto it = this->lookup.find(key);
\t\tif (it == this->lookup.end()) return nullptr;

\t\t/* Move to front if needed. */
\t\tthis->data.splice(this->data.begin(), this->data, it->second);

\t\treturn &this->data.front().second;
#endif
\t}''',
    "GetIfValid")

# ─── 6. graph_gui.cpp — Filler CTAD ───────────────────────────────────────
patch("src/graph_gui.cpp",
    '''\ttemplate <typename Tprojection>
\tstruct Filler : BaseFiller {
\t\tTprojection proj; ///< Projection to apply.

\t\tinline void Fill(uint i, const auto &data) const { this->dataset.values[i] = std::invoke(this->proj, data); }
\t};''',
    '''\ttemplate <typename Tprojection>
\tstruct Filler : BaseFiller {
\t\tTprojection proj; ///< Projection to apply.

#if defined(__GNUC__) && __GNUC__ < 11 && !defined(__clang__)
\t\tconstexpr Filler(DataSet &ds, Tprojection p) : BaseFiller{ds}, proj(p) {}
#endif

\t\tinline void Fill(uint i, const auto &data) const { this->dataset.values[i] = std::invoke(this->proj, data); }
\t};''',
    "Filler CTAD")

# ─── 7. format.hpp — GCC 10 concept-constrained formatter ────────────────
FORMAT_HPP = os.path.join(SRC, "src/core/format.hpp")
c = read(FORMAT_HPP)
if 'enable_if_t<std::is_enum_v<E>' not in c:
    new_content = r'''/*
 * This file is part of OpenTTD.
 * OpenTTD is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, version 2.
 * OpenTTD is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details. You should have received a copy of the GNU General Public License along with OpenTTD. If not, see <https://www.gnu.org/licenses/old-licenses/gpl-2.0>.
 */

/** @file format.hpp String formatting functions and helpers. */

#ifndef FORMAT_HPP
#define FORMAT_HPP

#include "../3rdparty/fmt/format.h"
#include "convertible_through_base.hpp"

#if defined(__GNUC__) && __GNUC__ < 11 && !defined(__clang__)
template <typename E, typename Char>
struct fmt::formatter<E, Char,
        std::enable_if_t<std::is_enum_v<E> && !ConvertibleThroughBase<E>>>
    : fmt::formatter<typename std::underlying_type_t<E>> {
	using underlying_type = typename std::underlying_type_t<E>;
	using parent = typename fmt::formatter<underlying_type>;
	constexpr fmt::format_parse_context::iterator parse(fmt::format_parse_context &ctx) { return parent::parse(ctx); }
	fmt::format_context::iterator format(const E &e, fmt::format_context &ctx) const { return parent::format(underlying_type(e), ctx); }
};
template <typename T, typename Char>
struct fmt::formatter<T, Char,
        std::enable_if_t<ConvertibleThroughBase<T>>>
    : fmt::formatter<typename T::BaseType> {
	using underlying_type = typename T::BaseType;
	using parent = typename fmt::formatter<underlying_type>;
	constexpr fmt::format_parse_context::iterator parse(fmt::format_parse_context &ctx) { return parent::parse(ctx); }
	fmt::format_context::iterator format(const T &t, fmt::format_context &ctx) const { return parent::format(t.base(), ctx); }
};
#else
template <typename E, typename Char> requires std::is_enum_v<E>
struct fmt::formatter<E, Char> : fmt::formatter<typename std::underlying_type_t<E>> {
	using underlying_type = typename std::underlying_type_t<E>;
	using parent = typename fmt::formatter<underlying_type>;
	constexpr fmt::format_parse_context::iterator parse(fmt::format_parse_context &ctx) { return parent::parse(ctx); }
	fmt::format_context::iterator format(const E &e, fmt::format_context &ctx) const { return parent::format(underlying_type(e), ctx); }
};
template <ConvertibleThroughBase T, typename Char>
struct fmt::formatter<T, Char> : fmt::formatter<typename T::BaseType> {
	using underlying_type = typename T::BaseType;
	using parent = typename fmt::formatter<underlying_type>;
	constexpr fmt::format_parse_context::iterator parse(fmt::format_parse_context &ctx) { return parent::parse(ctx); }
	fmt::format_context::iterator format(const T &t, fmt::format_context &ctx) const { return parent::format(t.base(), ctx); }
};
#endif

template <class... Args>
void format_append(std::string &out, fmt::format_string<Args...> &&fmt, Args&&... args)
{
	fmt::format_to(std::back_inserter(out), std::forward<decltype(fmt)>(fmt), std::forward<decltype(args)>(args)...);
}

#endif /* FORMAT_HPP */
'''
    write(FORMAT_HPP, new_content)
    print("  PATCHED: src/core/format.hpp (GCC10 formatter concepts)")
else:
    print("  OK (already): src/core/format.hpp")

# ─── 8. strgen_base.cpp — heterogeneous find + LanguagePackHeader init ────
patch("src/strgen/strgen_base.cpp",
    'auto it = this->name_to_string.find(s);',
    'auto it = this->name_to_string.find(std::string(s));',
    "name_to_string find string_view")

patch("src/strgen/strgen_base.cpp",
    '_strgen.lang = {};',
    '_strgen.lang = LanguagePackHeader();',
    "lang brace-init")

# ─── 9. convertible_through_base.hpp — SFINAE rewrite for GCC<11 ──────────
patch("src/core/convertible_through_base.hpp",
    '''template <typename T>
concept ConvertibleThroughBase = requires(T const a) {
\ttypename T::BaseType;
\t{ a.base() } noexcept -> std::convertible_to<int64_t>;
};''',
    '''#if defined(__GNUC__) && __GNUC__ < 11 && !defined(__clang__)
/* GCC 10: requires-expressions with noexcept + return-type constraints corrupt
 * the GGC tree and cause an ICE in complex template instantiation contexts.
 * Use a plain SFINAE trait instead. */
namespace detail {
template <typename T, typename = void>
struct _IsCtb : std::false_type {};
template <typename T>
struct _IsCtb<T, std::void_t<
\ttypename T::BaseType,
\tdecltype(std::declval<const T>().base())
>> : std::is_convertible<decltype(std::declval<const T>().base()), int64_t> {};
} // namespace detail
template <typename T>
concept ConvertibleThroughBase = detail::_IsCtb<T>::value;
#else
template <typename T>
concept ConvertibleThroughBase = requires(T const a) {
\ttypename T::BaseType;
\t{ a.base() } noexcept -> std::convertible_to<int64_t>;
};
#endif''',
    "ConvertibleThroughBase SFINAE rewrite")

# ─── 10. network_server.cpp — pragma GCC optimize O1 ─────────────────────
patch("src/network/network_server.cpp",
    '/** @file network_server.cpp Server part of the network protocol. */\n\n#include "../stdafx.h"',
    '/** @file network_server.cpp Server part of the network protocol. */\n\n/* GCC 10 ICE workaround: pragma O1 prevents optimizer ICEs in this TU */\n#pragma GCC optimize("O1")\n\n#include "../stdafx.h"',
    "pragma GCC optimize O1")

# ─── 11. squirrel_helper.hpp — pack expansion + if constexpr ICE ──────────
patch("src/script/squirrel_helper.hpp",
    '''\ttemplate <size_t... i>
\t\tstatic int SQCall(void *, Tretval(*func)(Targs...), [[maybe_unused]] HSQUIRRELVM vm, std::index_sequence<i...>)
\t\t{
\t\t\tif constexpr (std::is_void_v<Tretval>) {
\t\t\t\t(*func)(
\t\t\t\t\tParam<Targs>::Get(vm, 2 + i)...
\t\t\t\t);
\t\t\t\treturn 0;
\t\t\t} else {
\t\t\t\tTretval ret = (*func)(
\t\t\t\t\tParam<Targs>::Get(vm, 2 + i)...
\t\t\t\t);
\t\t\t\treturn Return<Tretval>::Set(vm, std::move(ret));
\t\t\t}
\t\t}
\t};''',
    '''\ttemplate <size_t... i>
\t\tstatic int SQCall(void *, Tretval(*func)(Targs...), [[maybe_unused]] HSQUIRRELVM vm, std::index_sequence<i...>)
\t\t{
#if defined(__GNUC__) && __GNUC__ < 11 && !defined(__clang__)
\t\t\tauto args = std::make_tuple(Param<Targs>::Get(vm, 2 + i)...);
\t\t\tif constexpr (std::is_void_v<Tretval>) {
\t\t\t\tstd::apply([func](std::decay_t<Targs>... a){ (*func)(std::move(a)...); }, std::move(args));
\t\t\t\treturn 0;
\t\t\t} else {
\t\t\t\tTretval ret = std::apply([func](std::decay_t<Targs>... a){ return (*func)(std::move(a)...); }, std::move(args));
\t\t\t\treturn Return<Tretval>::Set(vm, std::move(ret));
\t\t\t}
#else
\t\t\tif constexpr (std::is_void_v<Tretval>) {
\t\t\t\t(*func)(
\t\t\t\t\tParam<Targs>::Get(vm, 2 + i)...
\t\t\t\t);
\t\t\t\treturn 0;
\t\t\t} else {
\t\t\t\tTretval ret = (*func)(
\t\t\t\t\tParam<Targs>::Get(vm, 2 + i)...
\t\t\t\t);
\t\t\t\treturn Return<Tretval>::Set(vm, std::move(ret));
\t\t\t}
#endif
\t\t}
\t};''',
    "SQCall free func GCC<11")

patch("src/script/squirrel_helper.hpp",
    '''\ttemplate <size_t... i>
\t\tstatic int SQCall(Tcls *instance, Tretval(Tcls:: *func)(Targs...), [[maybe_unused]] HSQUIRRELVM vm, std::index_sequence<i...>)
\t\t{
\t\t\tif constexpr (std::is_void_v<Tretval>) {
\t\t\t\t(instance->*func)(
\t\t\t\t\tParam<Targs>::Get(vm, 2 + i)...
\t\t\t\t);
\t\t\t\treturn 0;
\t\t\t} else {
\t\t\t\tTretval ret = (instance->*func)(
\t\t\t\t\tParam<Targs>::Get(vm, 2 + i)...
\t\t\t\t);
\t\t\t\treturn Return<Tretval>::Set(vm, std::move(ret));
\t\t\t}
\t\t}''',
    '''\ttemplate <size_t... i>
\t\tstatic int SQCall(Tcls *instance, Tretval(Tcls:: *func)(Targs...), [[maybe_unused]] HSQUIRRELVM vm, std::index_sequence<i...>)
\t\t{
#if defined(__GNUC__) && __GNUC__ < 11 && !defined(__clang__)
\t\t\tauto args = std::make_tuple(Param<Targs>::Get(vm, 2 + i)...);
\t\t\tif constexpr (std::is_void_v<Tretval>) {
\t\t\t\tstd::apply([instance, func](std::decay_t<Targs>... a){ (instance->*func)(std::move(a)...); }, std::move(args));
\t\t\t\treturn 0;
\t\t\t} else {
\t\t\t\tTretval ret = std::apply([instance, func](std::decay_t<Targs>... a){ return (instance->*func)(std::move(a)...); }, std::move(args));
\t\t\t\treturn Return<Tretval>::Set(vm, std::move(ret));
\t\t\t}
#else
\t\t\tif constexpr (std::is_void_v<Tretval>) {
\t\t\t\t(instance->*func)(
\t\t\t\t\tParam<Targs>::Get(vm, 2 + i)...
\t\t\t\t);
\t\t\t\treturn 0;
\t\t\t} else {
\t\t\t\tTretval ret = (instance->*func)(
\t\t\t\t\tParam<Targs>::Get(vm, 2 + i)...
\t\t\t\t);
\t\t\t\treturn Return<Tretval>::Set(vm, std::move(ret));
\t\t\t}
#endif
\t\t}''',
    "SQCall member func GCC<11")

# ─── 12. endian_buffer.hpp — ConvertibleThroughBase auto → template form ──
patch("src/misc/endian_buffer.hpp",
    '\tEndianBufferWriter &operator <<(const ConvertibleThroughBase auto data)\n\t{\n\t\tthis->Write(data.base());\n\t\treturn *this;\n\t}\n\n\ttemplate <class T> requires (!std::is_class_v<T>)\n\tEndianBufferWriter &operator <<(const T data)',
    '''\ttemplate <ConvertibleThroughBase TCtb>
\tEndianBufferWriter &operator <<(const TCtb data)
\t{
\t\tthis->Write(data.base());
\t\treturn *this;
\t}

\ttemplate <class T, std::enable_if_t<!std::is_class_v<T>, int> = 0>
\tEndianBufferWriter &operator <<(const T data)''',
    "EndianBufferWriter op<< CTB")

patch("src/misc/endian_buffer.hpp",
    '\ttemplate <class T> requires (!std::is_class_v<T>)\n\tEndianBufferReader &operator >>(T &data)',
    '''\ttemplate <class T, std::enable_if_t<!std::is_class_v<T>, int> = 0>
\tEndianBufferReader &operator >>(T &data)''',
    "EndianBufferReader op>> requires")

# ─── 13. base_media_base.h — heterogeneous find in GetDescription ─────────
patch("src/base_media_base.h",
    '\t\tauto desc = this->description.find(isocode);\n\t\t\tif (desc != this->description.end()) return desc->second;\n\n\t\t\t/* Then the first two characters */\n\t\t\tdesc = this->description.find(isocode.substr(0, 2));',
    '''\t\tauto desc = this->description.find(std::string(isocode));
\t\t\tif (desc != this->description.end()) return desc->second;

\t\t\t/* Then the first two characters */
\t\t\tdesc = this->description.find(std::string(isocode.substr(0, 2)));''',
    "GetDescription find")

# ─── 14. Global: ConvertibleThroughBase auto → explicit template form ──────
def patch_ctb_auto(relpath, old, new, name):
    patch(relpath, old, new, name)

patch_ctb_auto("src/core/math_func.hpp",
    'template <typename To>\nconstexpr To ClampTo(ConvertibleThroughBase auto value)\n{\n\treturn ClampTo<To>(value.base());\n}',
    'template <typename To, ConvertibleThroughBase TFrom>\nconstexpr To ClampTo(TFrom value)\n{\n\treturn ClampTo<To>(value.base());\n}',
    "ClampTo CTB")

patch_ctb_auto("src/core/math_func.hpp",
    'constexpr bool IsInsideMM(const ConvertibleThroughBase auto x, const size_t min, const size_t max) noexcept { return IsInsideMM(x.base(), min, max); }',
    'template <ConvertibleThroughBase TIsIn>\nconstexpr bool IsInsideMM(const TIsIn x, const size_t min, const size_t max) noexcept { return IsInsideMM(x.base(), min, max); }',
    "IsInsideMM CTB")

patch_ctb_auto("src/window_func.h",
    'void InvalidateWindowData(WindowClass cls, WindowNumber number, ConvertibleThroughBase auto data, bool gui_scope = false) { InvalidateWindowData(cls, number, data.base(), gui_scope); }',
    'template <ConvertibleThroughBase TWinData>\nvoid InvalidateWindowData(WindowClass cls, WindowNumber number, TWinData data, bool gui_scope = false) { InvalidateWindowData(cls, number, data.base(), gui_scope); }',
    "InvalidateWindowData CTB")

patch_ctb_auto("src/window_func.h",
    'void InvalidateWindowClassesData(WindowClass cls, ConvertibleThroughBase auto data, bool gui_scope = false) { InvalidateWindowClassesData(cls, data.base(), gui_scope); }',
    'template <ConvertibleThroughBase TWinData>\nvoid InvalidateWindowClassesData(WindowClass cls, TWinData data, bool gui_scope = false) { InvalidateWindowClassesData(cls, data.base(), gui_scope); }',
    "InvalidateWindowClassesData CTB")

patch_ctb_auto("src/window_type.h",
    '\tWindowNumber(ConvertibleThroughBase auto value) : value(value.base()) {}',
    '\ttemplate <ConvertibleThroughBase TWN>\n\tWindowNumber(TWN value) : value(value.base()) {}',
    "WindowNumber ctor CTB")

patch_ctb_auto("src/window_type.h",
    '\tconstexpr bool operator==(const ConvertibleThroughBase auto &rhs) const { return this->value == static_cast<int32_t>(rhs.base()); }',
    '\ttemplate <ConvertibleThroughBase TWN>\n\tconstexpr bool operator==(const TWN &rhs) const { return this->value == static_cast<int32_t>(rhs.base()); }',
    "WindowNumber op== CTB")

patch_ctb_auto("src/command_type.h",
    'CommandCost CommandCostWithParam(StringID str, ConvertibleThroughBase auto value) { return CommandCostWithParam(str, value.base()); }',
    'template <ConvertibleThroughBase TCmdParam>\nCommandCost CommandCostWithParam(StringID str, TCmdParam value) { return CommandCostWithParam(str, value.base()); }',
    "CommandCostWithParam CTB")

patch_ctb_auto("src/newgrf_debug.h",
    'void InvalidateNewGRFInspectWindow(GrfSpecFeature feature, ConvertibleThroughBase auto index) { InvalidateNewGRFInspectWindow(feature, index.base()); }',
    'template <ConvertibleThroughBase TIdx>\nvoid InvalidateNewGRFInspectWindow(GrfSpecFeature feature, TIdx index) { InvalidateNewGRFInspectWindow(feature, index.base()); }',
    "InvalidateNewGRFInspectWindow CTB")

patch_ctb_auto("src/newgrf_debug.h",
    'void DeleteNewGRFInspectWindow(GrfSpecFeature feature, ConvertibleThroughBase auto index) { DeleteNewGRFInspectWindow(feature, index.base()); }',
    'template <ConvertibleThroughBase TIdx>\nvoid DeleteNewGRFInspectWindow(GrfSpecFeature feature, TIdx index) { DeleteNewGRFInspectWindow(feature, index.base()); }',
    "DeleteNewGRFInspectWindow CTB")

patch_ctb_auto("src/newgrf_debug_gui.cpp",
    'static inline uint GetInspectWindowNumber(GrfSpecFeature feature, ConvertibleThroughBase auto index) { return GetInspectWindowNumber(feature, index.base()); }',
    'template <ConvertibleThroughBase TIdx>\nstatic inline uint GetInspectWindowNumber(GrfSpecFeature feature, TIdx index) { return GetInspectWindowNumber(feature, index.base()); }',
    "GetInspectWindowNumber CTB")

patch_ctb_auto("src/order_cmd.cpp",
    'static bool OrderConditionCompare(OrderConditionComparator occ, ConvertibleThroughBase auto variable, int value)',
    'template <ConvertibleThroughBase TOcc>\nstatic bool OrderConditionCompare(OrderConditionComparator occ, TOcc variable, int value)',
    "OrderConditionCompare CTB")

patch_ctb_auto("src/source_type.h",
    '\tSource(ConvertibleThroughBase auto id, SourceType type) : id(id.base()), type(type) {}',
    '\ttemplate <ConvertibleThroughBase TSrcId>\n\tSource(TSrcId id, SourceType type) : id(id.base()), type(type) {}',
    "Source ctor CTB")

patch_ctb_auto("src/source_type.h",
    '\tconstexpr void SetIndex(ConvertibleThroughBase auto index) { this->id = index.base(); }',
    '\ttemplate <ConvertibleThroughBase TSrcId>\n\tconstexpr void SetIndex(TSrcId index) { this->id = index.base(); }',
    "Source::SetIndex CTB")

patch_ctb_auto("src/strings_internal.h",
    '\tvoid SetParam(size_t n, ConvertibleThroughBase auto v)',
    '\ttemplate <ConvertibleThroughBase TStrParam>\n\tvoid SetParam(size_t n, TStrParam v)',
    "SetParam CTB")

patch_ctb_auto("src/strings_type.h",
    '\tinline StringParameter(const ConvertibleThroughBase auto &data) : data(static_cast<uint64_t>(data.base())), type(0) {}',
    '\ttemplate <ConvertibleThroughBase TStrP>\n\tinline StringParameter(const TStrP &data) : data(static_cast<uint64_t>(data.base())), type(0) {}',
    "StringParameter ctor CTB")

patch_ctb_auto("src/vehiclelist.h",
    '\tconstexpr void SetIndex(ConvertibleThroughBase auto index) { this->index = index.base(); }',
    '\ttemplate <ConvertibleThroughBase TVLIdx>\n\tconstexpr void SetIndex(TVLIdx index) { this->index = index.base(); }',
    "VehicleListIdentifier::SetIndex CTB")

patch_ctb_auto("src/vehiclelist.h",
    '\tVehicleListIdentifier(VehicleListType type, VehicleType vtype, CompanyID company, ConvertibleThroughBase auto index) :',
    '\ttemplate <ConvertibleThroughBase TVLIdx>\n\tVehicleListIdentifier(VehicleListType type, VehicleType vtype, CompanyID company, TVLIdx index) :',
    "VehicleListIdentifier ctor CTB")

patch_ctb_auto("src/saveload/saveload.h",
    'static void SlSetArrayIndex(const ConvertibleThroughBase auto &index) { SlSetArrayIndex(index.base()); }',
    'template <ConvertibleThroughBase TSLIdx>\nstatic void SlSetArrayIndex(const TSLIdx &index) { SlSetArrayIndex(index.base()); }',
    "SlSetArrayIndex CTB")

patch_ctb_auto("src/network/core/packet.h",
    '\tvoid   Send_uint8 (const ConvertibleThroughBase auto &data) { this->Send_uint8(data.base()); }',
    '\ttemplate <ConvertibleThroughBase TPkt>\n\tvoid   Send_uint8 (const TPkt &data) { this->Send_uint8(data.base()); }',
    "Packet::Send_uint8 CTB")

patch_ctb_auto("src/script/squirrel.hpp",
    '\tvoid AddConst(std::string_view var_name, const ConvertibleThroughBase auto &value) { this->AddConst(var_name, static_cast<SQInteger>(value.base())); }',
    '\ttemplate <ConvertibleThroughBase TSqConst>\n\tvoid AddConst(std::string_view var_name, const TSqConst &value) { this->AddConst(var_name, static_cast<SQInteger>(value.base())); }',
    "Squirrel::AddConst CTB")

patch_ctb_auto("src/script/squirrel.hpp",
    '\tvoid InsertResult(ConvertibleThroughBase auto result) { this->InsertResult(static_cast<int>(result.base())); }',
    '\ttemplate <ConvertibleThroughBase TSqRes>\n\tvoid InsertResult(TSqRes result) { this->InsertResult(static_cast<int>(result.base())); }',
    "Squirrel::InsertResult CTB")

# ─── 15. network_admin.h — C-array workaround for std::array<EnumBitSet> ICE
# With PCH disabled (-DCMAKE_DISABLE_PRECOMPILE_HEADERS=ON), the #if in class
# body works correctly. The std::array<EnumBitSet>::operator[] triggers a GCC 10
# ICE ("using invalid field _M_elems") via PCH; C-array avoids it entirely.
patch("src/network/network_admin.h",
    'std::array<AdminUpdateFrequencies, ADMIN_UPDATE_END> update_frequency{}; ///< Admin requested update intervals.',
    '''#if defined(__GNUC__) && __GNUC__ < 11 && !defined(__clang__)
/* GCC 10 + PCH disabled: std::array<EnumBitSet,N>::operator[] ICE workaround */
AdminUpdateFrequencies update_frequency[ADMIN_UPDATE_END]{};
#else
std::array<AdminUpdateFrequencies, ADMIN_UPDATE_END> update_frequency{};
#endif
///< Admin requested update intervals.''',
    "network_admin.h C-array workaround")

# ─── 16. settings.cpp — pragma O1 (ICE at -O2 in basic_string.tcc) ────────
patch("src/settings.cpp",
    '/** @file settings.cpp',
    '/* GCC 10 ICE workaround: basic_string.tcc:472 at -O2 */\n#pragma GCC optimize("O1")\n\n/** @file settings.cpp',
    "settings.cpp pragma O1")

# ─── 17. gfx_layout.h — extern template for FontColourMap after Layouter ──
# Suppresses GCC 10 ICE in std::map<TextColour,unique_ptr<Font>>::_M_erase
# The extern template must be OUTSIDE the class body.
c = read(os.path.join(SRC, "src/gfx_layout.h"))
if 'extern template class std::map<TextColour' not in c:
    # Find the closing }; of the Layouter class and insert after it
    # Layouter class has "static FontColourMap fonts[FS_END];" as a member
    idx = c.find('\tstatic FontColourMap fonts[FS_END];')
    if idx >= 0:
        # Find the next "};" after this point
        end_idx = c.find('};', idx)
        if end_idx >= 0:
            insert_pos = end_idx + 2  # after "};"
            insert_text = (
                '\n\n#if defined(__GNUC__) && __GNUC__ < 11 && !defined(__clang__)\n'
                '/* GCC 10 ICE: suppress std::map<TextColour,unique_ptr<Font>> _M_erase instantiation */\n'
                'extern template class std::map<TextColour, std::unique_ptr<Font>>;\n'
                '#endif'
            )
            c = c[:insert_pos] + insert_text + c[insert_pos:]
            write(os.path.join(SRC, "src/gfx_layout.h"), c)
            print("  PATCHED: src/gfx_layout.h (FontColourMap extern template)")
        else:
            print("  WARNING: gfx_layout.h could not find }; after fonts member")
    else:
        print("  WARNING: gfx_layout.h could not find fonts member")
else:
    print("  OK (already): src/gfx_layout.h")

# ─── 18. gfx_layout.cpp — explicit FontColourMap instantiation at O1 ──────
patch("src/gfx_layout.cpp",
    '#include "safeguards.h"',
    '''#include "safeguards.h"

#if defined(__GNUC__) && __GNUC__ < 11 && !defined(__clang__)
/* GCC 10: explicit instantiation of FontColourMap here (suppressed elsewhere). */
#pragma GCC push_options
#pragma GCC optimize("O1")
template class std::map<TextColour, std::unique_ptr<Font>>;
#pragma GCC pop_options
#endif''',
    "gfx_layout.cpp FontColourMap explicit instantiation")

# ─── 19. Bulk pragma O1 — all .cpp files ──────────────────────────────────
# GCC 10 ICEs at -O2 in many template-heavy files (symtab.c:428, Segfault etc.)
# Pragma O1 is the sweet spot: basic optimization without the -O2 ICE triggers.
# Applied to: src/**/*.cpp (all top-level + subdirs)
PRAGMA_O1 = '#pragma GCC optimize("O1")  /* GCC 10 ICE workaround: bulk */\n\n'
MARKER = '/** @file'
bulk_patched = 0
bulk_targets = (
    glob.glob(f"{SRC}/src/*.cpp") +
    glob.glob(f"{SRC}/src/network/*.cpp") +
    glob.glob(f"{SRC}/src/script/*.cpp") +
    glob.glob(f"{SRC}/src/script/api/*.cpp") +
    glob.glob(f"{SRC}/src/ai/*.cpp") +
    glob.glob(f"{SRC}/src/ai/api/*.cpp") +
    glob.glob(f"{SRC}/src/game/*.cpp") +
    glob.glob(f"{SRC}/src/game/api/*.cpp") +
    glob.glob(f"{SRC}/src/saveload/*.cpp") +
    glob.glob(f"{SRC}/src/fontcache/*.cpp") +
    glob.glob(f"{SRC}/src/os/**/*.cpp", recursive=True)
)
# Files that include nlohmann/json.hpp need O0, not O1 (deeper ICE trigger)
JSON_HEAVY_FILES = {
    "src/script/api/script_admin.cpp",
    "src/script/api/script_event_types.cpp",
}

for fpath in sorted(set(bulk_targets)):
    fc = open(fpath).read()
    if '#pragma GCC optimize' in fc:
        continue  # already has a pragma (possibly O0 or O1 from individual patches above)
    # json-heavy files need O0, others get O1
    relpath_check = fpath.replace(SRC + "/", "")
    if relpath_check in JSON_HEAVY_FILES:
        pragma = '#pragma GCC optimize("O0")  /* GCC 10 ICE workaround: json-heavy TU */\n\n'
    else:
        pragma = PRAGMA_O1
    if MARKER in fc:
        fc = fc.replace(MARKER, pragma + MARKER, 1)
    else:
        idx = fc.find('\n\n')
        fc = fc[:idx+2] + pragma + fc[idx+2:] if idx >= 0 else pragma + fc
    open(fpath, 'w').write(fc)
    bulk_patched += 1
print(f"  Bulk pragma O1: {bulk_patched} files patched")

# ─── 20. nlohmann/json.hpp — pragma O0 push/pop ──────────────────────────
# GCC 10 ICEs (stl_tree.h Segfault) when instantiating json.hpp templates at O1+.
JSON_HPP = os.path.join(SRC, "src/3rdparty/nlohmann/json.hpp")
jc = read(JSON_HPP)
if '#pragma GCC push_options' not in jc:
    header_pragma = '#ifdef __GNUC__\n#pragma GCC push_options\n#pragma GCC optimize("O0")  /* GCC 10 ICE workaround */\n#endif\n'
    footer_pragma = '#ifdef __GNUC__\n#pragma GCC pop_options\n#endif\n'
    first_guard = jc.find('#ifndef')
    if first_guard > 0:
        jc = jc[:first_guard] + header_pragma + jc[first_guard:]
    last_endif = jc.rfind('#endif')
    if last_endif > 0:
        jc = jc[:last_endif] + footer_pragma + jc[last_endif:]
    write(JSON_HPP, jc)
    print("  PATCHED: src/3rdparty/nlohmann/json.hpp (pragma O0 push/pop)")
else:
    print("  OK (already): src/3rdparty/nlohmann/json.hpp")

print("=== All patches applied ===")
