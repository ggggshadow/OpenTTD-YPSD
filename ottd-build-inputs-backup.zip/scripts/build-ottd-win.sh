#!/usr/bin/env bash
# ============================================================
# OpenTTD 15.3 Windows x64 cross-compile — llvm-mingw (Clang 22)
#
# Toolchain: llvm-mingw (Clang 22 + MSVCRT), downloaded from
#   https://github.com/mstorsjo/llvm-mingw
#
# Why llvm-mingw instead of GCC 10 MinGW:
#   GCC 10.3.0 (only version in this nixpkgs) has multiple ICEs with
#   OpenTTD 15.3's C++20 code. Any pragma-based workaround changes
#   runtime behavior. Clang 22 compiles vanilla 15.3 correctly with
#   only two minimal non-behavioral fixes:
#     1. fmt/format.h: #include <stdlib.h> for malloc/free (global NS)
#     2. fmt/os.cc: stubbed out (OpenTTD never includes fmt/os.h)
#
# Result: statically linked openttd.exe (~286 MB, no DLLs needed)
#
# Persistent storage (workspace/build/*):
#   - Static libs compiled once, reused across restarts
#   - llvm-mingw downloaded once to /tmp/llvm-msvcrt/ (re-download on wipe)
# ============================================================
set -e

OTTD_SRC="/tmp/ottd_clean/openttd-15.3"
BUILD_WIN="/tmp/build_win_llvm"
BUILD_LINUX="/tmp/build_linux"
LIBS_SRC="/tmp/libs_src"
DIST="/home/runner/workspace/dist"
WORKSPACE="/home/runner/workspace"

# Persistent lib install paths (survive container restart)
LLVM_LIBS="$WORKSPACE/build/llvm_libs"
ZLIB="$LLVM_LIBS/zlib"
LZMA="$LLVM_LIBS/lzma"
PNG="$LLVM_LIBS/libpng"

# llvm-mingw (re-downloaded to /tmp on restart)
LLVM_DIR="/tmp/llvm-msvcrt"
LLVM="$LLVM_DIR/bin"

echo "========================================"
echo " OpenTTD 15.3 Win x64 build (Clang 22)"
echo "========================================"

# ─────────────────────────────────────────
# 0. ENSURE PERSISTENT DIRS
# ─────────────────────────────────────────
mkdir -p "$ZLIB" "$LZMA" "$PNG" "$DIST"

# ─────────────────────────────────────────
# 1. DOWNLOAD llvm-mingw (MSVCRT, Ubuntu 22.04, x86_64)
# ─────────────────────────────────────────
if [ ! -f "$LLVM/x86_64-w64-mingw32-clang++" ]; then
  echo "[1/8] Downloading llvm-mingw (Clang 22, ~78 MB)..."
  mkdir -p /tmp/llvm-msvcrt
  # Find latest release URL
  RELEASE_URL=$(curl -sL "https://api.github.com/repos/mstorsjo/llvm-mingw/releases/latest" \
    | python3 -c "import json,sys; r=json.load(sys.stdin); \
      url=[a['browser_download_url'] for a in r['assets'] \
           if 'msvcrt' in a['name'] and 'ubuntu-22.04' in a['name'] \
           and 'x86_64' in a['name'] and a['name'].endswith('.tar.xz')]; \
      print(url[0] if url else '')")
  if [ -z "$RELEASE_URL" ]; then
    # Fallback to known-good URL
    RELEASE_URL="https://github.com/mstorsjo/llvm-mingw/releases/download/20260616/llvm-mingw-20260616-msvcrt-ubuntu-22.04-x86_64.tar.xz"
  fi
  curl -L "$RELEASE_URL" | tar -xJ -C /tmp/llvm-msvcrt --strip-components=1
  echo "  Clang: $($LLVM/x86_64-w64-mingw32-clang++ --version | head -1)"
else
  echo "[1/8] llvm-mingw already present"
fi

# ─────────────────────────────────────────
# 2. CLONE SOURCE
# ─────────────────────────────────────────
if [ ! -d "$OTTD_SRC" ]; then
  echo "[2/8] Cloning OpenTTD 15.3..."
  mkdir -p /tmp/ottd_clean
  nix-shell -p git --run \
    "git clone --depth=1 --branch 15.3 https://github.com/OpenTTD/OpenTTD.git $OTTD_SRC"
else
  echo "[2/8] Source already present"
fi

# ─────────────────────────────────────────
# 3. APPLY MINIMAL COMPILE FIXES (non-behavioral)
# ─────────────────────────────────────────
echo "[3/8] Applying minimal Clang/Windows compat fixes..."
python3 - << 'PYEOF'
SRC = "/tmp/ottd_clean/openttd-15.3"

# Fix 1: fmt/format.h — include stdlib.h for malloc/free in global namespace
# (libc++ requires explicit include; use <stdlib.h> not <cstdlib> to avoid
# libc++ stdlib.h ldiv/lldiv wrapper bug with MinGW cross-compilation)
path = f"{SRC}/src/3rdparty/fmt/format.h"
c = open(path).read()
marker = "// An allocator that uses malloc/free"
fix = "#include <stdlib.h>  // clang cross-compile: global-ns malloc/free\n\n" + marker
if marker in c and '<stdlib.h>' not in c:
    open(path, 'w').write(c.replace(marker, fix, 1))
    print("  PATCHED: fmt/format.h (stdlib.h include)")
elif '<stdlib.h>' in c:
    print("  OK (already): fmt/format.h")
else:
    print("  WARNING: fmt/format.h marker not found")

# Fix 2: fmt/os.cc — stub out (OpenTTD never includes fmt/os.h)
# Avoids libc++ stdlib.h ldiv/lldiv ordering bug triggered during os.cc compilation
path2 = f"{SRC}/src/3rdparty/fmt/os.cc"
stub = "// fmt/os.cc stub — OpenTTD does not use fmt OS I/O features.\n"
c2 = open(path2).read()
if stub not in c2:
    open(path2, 'w').write(stub)
    print("  PATCHED: fmt/os.cc (stubbed)")
else:
    print("  OK (already): fmt/os.cc")
PYEOF

# ─────────────────────────────────────────
# 4. COMPILE STATIC LIBRARIES (persistent)
# ─────────────────────────────────────────
mkdir -p "$LIBS_SRC"

# zlib
if [ ! -f "$ZLIB/lib/libz.a" ]; then
  echo "[4/8] Compiling zlib..."
  cd "$LIBS_SRC"
  [ ! -d zlib-1.3.1 ] && curl -sL https://github.com/madler/zlib/releases/download/v1.3.1/zlib-1.3.1.tar.gz | tar xz
  cd zlib-1.3.1
  make distclean 2>/dev/null || true
  CC="$LLVM/x86_64-w64-mingw32-clang" AR="$LLVM/x86_64-w64-mingw32-llvm-ar" \
    RANLIB="$LLVM/x86_64-w64-mingw32-llvm-ranlib" \
    ./configure --prefix="$ZLIB" --static 2>&1 | tail -1
  make -j$(nproc) libz.a && make install
  echo "  zlib: OK"
else
  echo "[4/8] zlib already compiled"
fi

# liblzma (cmake build — avoids autoconf libtool/w32res issues)
if [ ! -f "$LZMA/lib/liblzma.a" ]; then
  echo "[4/8] Compiling liblzma..."
  cd "$LIBS_SRC"
  [ ! -d xz-5.4.6 ] && curl -sL https://github.com/tukaani-project/xz/releases/download/v5.4.6/xz-5.4.6.tar.gz | tar xz
  mkdir -p /tmp/lzma_llvm_build
  nix-shell -p cmake ninja --run "
    cmake '$LIBS_SRC/xz-5.4.6' -G Ninja -B /tmp/lzma_llvm_build \
      -DCMAKE_SYSTEM_NAME=Windows \
      -DCMAKE_C_COMPILER=$LLVM/x86_64-w64-mingw32-clang \
      -DCMAKE_AR=$LLVM/x86_64-w64-mingw32-llvm-ar \
      -DCMAKE_BUILD_TYPE=Release \
      -DBUILD_SHARED_LIBS=OFF -DENABLE_NLS=OFF 2>&1 | tail -2
    ninja -C /tmp/lzma_llvm_build liblzma -j\$(nproc) 2>&1 | tail -3
  "
  mkdir -p "$LZMA/lib" "$LZMA/include"
  cp /tmp/lzma_llvm_build/liblzma.a "$LZMA/lib/"
  cp "$LIBS_SRC/xz-5.4.6/src/liblzma/api/lzma.h" "$LZMA/include/"
  cp -r "$LIBS_SRC/xz-5.4.6/src/liblzma/api/lzma" "$LZMA/include/"
  echo "  liblzma: OK"
else
  echo "[4/8] liblzma already compiled"
fi

# libpng
if [ ! -f "$PNG/lib/libpng.a" ] && [ ! -f "$PNG/lib/libpng16.a" ]; then
  echo "[4/8] Compiling libpng..."
  cd "$LIBS_SRC"
  [ ! -d libpng-1.6.43 ] && curl -sL 'https://sourceforge.net/projects/libpng/files/libpng16/1.6.43/libpng-1.6.43.tar.gz/download' | tar xz
  cd libpng-1.6.43
  make distclean 2>/dev/null || true
  ./configure --host=x86_64-w64-mingw32 --build=x86_64-linux-gnu \
    --prefix="$PNG" --enable-static --disable-shared \
    CC="$LLVM/x86_64-w64-mingw32-clang" \
    AR="$LLVM/x86_64-w64-mingw32-llvm-ar" \
    RANLIB="$LLVM/x86_64-w64-mingw32-llvm-ranlib" \
    CPPFLAGS="-I$ZLIB/include" LDFLAGS="-L$ZLIB/lib" 2>&1 | tail -1
  make -j$(nproc) && make install
  echo "  libpng: OK"
else
  echo "[4/8] libpng already compiled"
fi

# ─────────────────────────────────────────
# 5. LINUX HOST TOOLS (strgen + settingsgen)
# ─────────────────────────────────────────
if [ ! -f "$BUILD_LINUX/src/strgen/strgen" ]; then
  echo "[5/8] Building Linux host tools (strgen/settingsgen)..."
  mkdir -p "$BUILD_LINUX"
  nix-shell -p cmake ninja gcc --run "
    cmake '$OTTD_SRC' -G Ninja -B '$BUILD_LINUX' \
      -DCMAKE_BUILD_TYPE=Release -DOPTION_TOOLS_ONLY=ON \
      -DCMAKE_CXX_FLAGS='-std=c++20' 2>&1 | tail -3
    ninja -C '$BUILD_LINUX' strgen settingsgen -j\$(nproc) 2>&1 | tail -3
  "
  echo "  Host tools: OK"
else
  echo "[5/8] Linux host tools already present"
fi

# ─────────────────────────────────────────
# 6. CMAKE TOOLCHAIN FILE
# ─────────────────────────────────────────
echo "[6/8] Writing toolchain file..."
PNG_LIB="$PNG/lib/libpng16.a"
[ -f "$PNG/lib/libpng.a" ] && PNG_LIB="$PNG/lib/libpng.a"
PNG_INC="$PNG/include/libpng16"
[ -d "$PNG/include/libpng" ] && PNG_INC="$PNG/include/libpng"

cat > /tmp/llvm-msvcrt-toolchain.cmake << EOF
set(CMAKE_SYSTEM_NAME Windows)
set(CMAKE_SYSTEM_PROCESSOR x86_64)
set(CMAKE_C_COMPILER   $LLVM/x86_64-w64-mingw32-clang)
set(CMAKE_CXX_COMPILER $LLVM/x86_64-w64-mingw32-clang++)
set(CMAKE_RC_COMPILER  $LLVM/x86_64-w64-mingw32-windres)
set(CMAKE_AR           $LLVM/x86_64-w64-mingw32-llvm-ar)
set(CMAKE_RANLIB       $LLVM/x86_64-w64-mingw32-llvm-ranlib)
set(CMAKE_FIND_ROOT_PATH_MODE_PROGRAM NEVER)
set(CMAKE_FIND_ROOT_PATH_MODE_LIBRARY ONLY)
set(CMAKE_FIND_ROOT_PATH_MODE_INCLUDE ONLY)
set(ZLIB_ROOT          "$ZLIB")
set(ZLIB_INCLUDE_DIR   "$ZLIB/include")
set(ZLIB_LIBRARY       "$ZLIB/lib/libz.a")
set(LIBLZMA_INCLUDE_DIR "$LZMA/include")
set(LIBLZMA_LIBRARY    "$LZMA/lib/liblzma.a")
set(PNG_ROOT           "$PNG")
set(PNG_PNG_INCLUDE_DIR "$PNG_INC")
set(PNG_LIBRARY        "$PNG_LIB")
set(CMAKE_CXX_FLAGS    "-std=c++20 -Wno-ignored-attributes -Wno-deprecated-declarations")
set(CMAKE_EXE_LINKER_FLAGS "-static")
EOF

# ─────────────────────────────────────────
# 7. CMAKE CONFIGURE + BUILD
# ─────────────────────────────────────────
echo "[7/8] Configuring cmake..."
mkdir -p "$BUILD_WIN"
nix-shell -p cmake ninja --run "
  cmake '$OTTD_SRC' \
    -G Ninja -B '$BUILD_WIN' \
    -DCMAKE_TOOLCHAIN_FILE=/tmp/llvm-msvcrt-toolchain.cmake \
    -DCMAKE_BUILD_TYPE=RelWithDebInfo \
    -DOPTION_USE_ASSERTS=OFF \
    -DCMAKE_DISABLE_PRECOMPILE_HEADERS=ON \
    -DHOST_BINARY_DIR='$BUILD_LINUX' \
    -DZLIB_ROOT=$ZLIB \
    -DLIBLZMA_INCLUDE_DIR=$LZMA/include \
    -DLIBLZMA_LIBRARY=$LZMA/lib/liblzma.a \
    -DPNG_ROOT=$PNG \
    -DPNG_PNG_INCLUDE_DIR=$PNG_INC \
    -DPNG_LIBRARY=$PNG_LIB \
    2>&1 | grep -E 'error|Configuring done|Generating done'
"

echo "[8/8] Building openttd.exe..."
nix-shell -p cmake ninja --run "
  ninja -C '$BUILD_WIN' openttd -j\$(nproc) 2>&1 \
    | grep -E 'error:|FAILED|Linking CXX|Built target openttd' \
    | grep -v 'DWARF error'
"

if [ -f "$BUILD_WIN/openttd.exe" ]; then
  echo "========================================"
  echo " openttd.exe OK: $(du -sh $BUILD_WIN/openttd.exe | cut -f1)"
  echo "========================================"
  bash "$WORKSPACE/scripts/package-ottd-win.sh" "$BUILD_WIN"
else
  echo "ERROR: openttd.exe not found"
  exit 1
fi
