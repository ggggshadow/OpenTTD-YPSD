#!/usr/bin/env bash
# Writes GCC 10 MinGW compat stubs (span, source_location, bit) to $1 directory
mkdir -p "$1"
cat > "$1/span" << 'SPANEOF'
#pragma once
#ifndef _MINGW_COMPAT_SPAN_H
#define _MINGW_COMPAT_SPAN_H
#include <cstddef>
#include <iterator>
#include <type_traits>
#include <array>
#include <ranges>
namespace std {
inline constexpr size_t dynamic_extent = static_cast<size_t>(-1);
template<class T, size_t Extent = dynamic_extent>
class span {
public:
    using element_type=T; using value_type=remove_cv_t<T>; using size_type=size_t;
    using difference_type=ptrdiff_t; using pointer=T*; using const_pointer=const T*;
    using reference=T&; using const_reference=const T&; using iterator=T*;
    using reverse_iterator=std::reverse_iterator<iterator>;
    static constexpr size_t extent=Extent;
    constexpr span() noexcept:_data(nullptr),_size(0){}
    constexpr span(T* ptr,size_type count) noexcept:_data(ptr),_size(count){}
    constexpr span(T* first,T* last) noexcept:_data(first),_size(last-first){}
    template<size_t N> constexpr span(T (&arr)[N]) noexcept:_data(arr),_size(N){}
    template<size_t N> constexpr span(array<value_type,N>&arr) noexcept:_data(arr.data()),_size(N){}
    template<size_t N> constexpr span(const array<value_type,N>&arr) noexcept:_data(arr.data()),_size(N){}
    template<typename R,typename=void_t<decltype(std::data(std::declval<R&>())),decltype(std::size(std::declval<R&>()))>,typename=enable_if_t<!is_array_v<remove_reference_t<R>>&&!is_same_v<remove_cvref_t<R>,span>>>
    constexpr span(R&&r) noexcept:_data(std::data(r)),_size(std::size(r)){}
    template<typename It,typename=void_t<decltype(std::to_address(std::declval<It>()))>>
    constexpr span(It first,It last) noexcept:_data(std::to_address(first)),_size(last-first){}
    constexpr span(const span&) noexcept=default;
    constexpr span& operator=(const span&) noexcept=default;
    constexpr iterator begin() const noexcept{return _data;}
    constexpr iterator end() const noexcept{return _data+_size;}
    constexpr reverse_iterator rbegin() const noexcept{return reverse_iterator(end());}
    constexpr reverse_iterator rend() const noexcept{return reverse_iterator(begin());}
    constexpr reference front() const{return _data[0];}
    constexpr reference back() const{return _data[_size-1];}
    constexpr reference operator[](size_type i) const{return _data[i];}
    constexpr pointer data() const noexcept{return _data;}
    constexpr size_type size() const noexcept{return _size;}
    constexpr size_type size_bytes() const noexcept{return _size*sizeof(T);}
    constexpr bool empty() const noexcept{return _size==0;}
    constexpr span<T> subspan(size_type offset,size_type count=dynamic_extent) const{return{_data+offset,count==dynamic_extent?_size-offset:count};}
    constexpr span<T> first(size_type n) const{return{_data,n};}
    constexpr span<T> last(size_type n) const{return{_data+_size-n,n};}
private:
    T* _data; size_type _size;
};
template<typename T,size_t N> span(T(&)[N])->span<T,N>;
template<typename T,size_t N> span(array<T,N>&)->span<T,N>;
template<typename T,size_t N> span(const array<T,N>&)->span<const T,N>;
template<typename T> span(T*,size_t)->span<T>;
template<typename T> span(T*,T*)->span<T>;
template<typename R,typename E=remove_pointer_t<decltype(std::data(std::declval<R&>()))>>
span(R&&)->span<E>;
} // namespace std
// Required for span | std::views::filter(...) to work
template<class T, std::size_t E>
inline constexpr bool std::ranges::enable_view<std::span<T,E>> = true;
template<class T, std::size_t E>
inline constexpr bool std::ranges::enable_borrowed_range<std::span<T,E>> = true;
#endif
SPANEOF

cat > "$1/source_location" << 'SLEOF'
#pragma once
#include <cstdint>
namespace std {
struct source_location {
    static constexpr source_location current(
        const char* _file=__builtin_FILE(),
        uint_least32_t _line=__builtin_LINE(),
        const char* _func=__builtin_FUNCTION()) noexcept {
        source_location sl; sl._file_name=_file; sl._line=_line; sl._func_name=_func; return sl;
    }
    constexpr const char* file_name() const noexcept{return _file_name;}
    constexpr uint_least32_t line() const noexcept{return _line;}
    constexpr uint_least32_t column() const noexcept{return 0;}
    constexpr const char* function_name() const noexcept{return _func_name;}
private:
    const char* _file_name=""; uint_least32_t _line=0; const char* _func_name="";
};
}
SLEOF

cat > "$1/bit" << 'BITEOF'
#pragma once
// GCC 10 MinGW <bit> lacks std::bit_cast. Provide it via memcpy.
#include_next <bit>
#ifndef __cpp_lib_bit_cast
#include <cstring>
#include <type_traits>
namespace std {
template<class To, class From>
std::enable_if_t<
    sizeof(To) == sizeof(From) &&
    std::is_trivially_copyable_v<From> &&
    std::is_trivially_copyable_v<To>,
    To>
bit_cast(const From& src) noexcept {
    To dst;
    std::memcpy(&dst, &src, sizeof(To));
    return dst;
}
}
#endif
BITEOF
echo "Stubs written OK"
