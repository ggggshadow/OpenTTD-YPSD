#!/usr/bin/env bash
# Package openttd.exe + lang + baseset into a zip in dist/
# Usage: package-ottd-win.sh [build_dir]
set -e

BUILD_WIN="${1:-/tmp/build_win_llvm}"
DIST="/home/runner/workspace/dist"
DIST_TMP="/tmp/ottd_dist_pkg"
ZIPNAME="openttd-15.3-win-x64.zip"

rm -rf "$DIST_TMP"
mkdir -p "$DIST_TMP/lang" "$DIST_TMP/baseset" "$DIST"

echo "Packaging from: $BUILD_WIN"

# exe
cp "$BUILD_WIN/openttd.exe" "$DIST_TMP/"

# lang files
if ls "$BUILD_WIN/lang/"*.lng 1>/dev/null 2>&1; then
  cp "$BUILD_WIN/lang/"*.lng "$DIST_TMP/lang/"
else
  echo "WARNING: no .lng files found in $BUILD_WIN/lang/"
fi

# baseset (GRF files)
if ls "$BUILD_WIN/baseset/"*.grf 1>/dev/null 2>&1; then
  cp "$BUILD_WIN/baseset/"*.grf "$DIST_TMP/baseset/"
  cp "$BUILD_WIN/baseset/"*.obg "$DIST_TMP/baseset/" 2>/dev/null || true
fi

# Note: build with -static, no DLLs needed
# (llvm-mingw + -static links libc++, libgcc, etc. into exe)

cd "$DIST_TMP"
zip -r "$DIST/$ZIPNAME" . 2>&1 | tail -3

echo "=== Packaged: $DIST/$ZIPNAME ==="
ls -lh "$DIST/$ZIPNAME"
echo "  exe: $(du -sh $DIST_TMP/openttd.exe | cut -f1)"
echo "  langs: $(ls $DIST_TMP/lang/*.lng 2>/dev/null | wc -l)"
echo "  baseset: $(ls $DIST_TMP/baseset/ 2>/dev/null | wc -l) files"
